Module Module1
    Sub Main()

    Dim myText As String = "You can get what you want out of life " & _
        "if you help enough other people get what they want."

    Dim charArray() As Char = myText.ToCharArray()

        Array.Reverse(charArray)

        For Each myChar As Char In charArray
        Console.Write(myChar)
        Next

    Console.ReadLine()
    End Sub

End Module